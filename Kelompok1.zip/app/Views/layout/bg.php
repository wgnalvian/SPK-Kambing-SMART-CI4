<div class="bg">
           <img src="<?= base_url("images/taman.png")?>">
             <img src="<?= base_url("images/taman.png")?>">
             <img src="<?= base_url("images/taman.png")?>">
             <img src="<?= base_url("images/taman.png")?>">
       </div>